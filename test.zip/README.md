# Other-Paper-Blossoms
Paper Blossoms Inspired character generator for Legend of the Five Rings.


# Dev mode
Simply run a web server; example in Python: 

python -m http.server
